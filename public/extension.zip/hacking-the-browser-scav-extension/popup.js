var apiBaseUrl = 'https://htb-week-6.herokuapp.com/api/quiz/';

$(function() {
  checkQuizResults({restore: true, checkComplete: true});

  $('a[data-link]').click(function() {
    var url = $(this).data('link');

    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      var tab = tabs[0]
      chrome.tabs.update(tab.id, {url: url});
    });
  });

  $('input[data-quiz]').keyup(function(e) {
    if (e.keyCode === 13) {
      var guess = $(this).val();
      var quiz = $(this).data('quiz');
      var url = apiBaseUrl + quiz;

      $.post(url, {guess: guess}).then(function(result) {
        storeResult(quiz, result.correct, function() {
          if (result.correct) {
            handleCorrectResult(quiz);
          } else {
            handleIncorrectResult(quiz);
          }
          checkQuizResults({checkComplete:true});
        });
      });
    }
  });
});

function getQuizNames() {
  var quizNames = [];
  $('[data-quiz]').each(function() {
    quizNames.push($(this).data('quiz'));
  });
  return quizNames;
}

function checkQuizResults(options) {
  var quizNames = getQuizNames();

  console.log(quizNames);
  chrome.storage.local.get(quizNames, function(result) {
    var allComplete = true;

    quizNames.forEach(function(name) {
      if (result[name]) {
        if (options.restore) {
          handleCorrectResult(name);
        }
      } else {
        allComplete = false;
      }
    });

    if (allComplete && options.checkComplete) {
      makeEffect();
    }
  });
}

function storeResult(quiz, correct, callback) {
  var obj = {};
  obj[quiz] = correct;
  chrome.storage.local.set(obj, callback);
}

function handleCorrectResult(quiz) {
  var cell = $('input[data-quiz="' + quiz + '"]').parent('.cell');
  cell.css({'background-color':'green'});
}
function handleIncorrectResult(quiz) {
  var cell = $('input[data-quiz="' + quiz + '"]').parent('.cell');
  cell.css({'background-color':'red'});
  setTimeout(function() {
    cell.css({'background-color':'white'});
  }, 500);
}

function makeEffect() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0]
    chrome.tabs.executeScript(tab.id, {file:'jquery.js'}, function() {
			chrome.tabs.executeScript(tab.id, {file:'lodash.js'}, function() {
        chrome.tabs.executeScript(tab.id, {file:'effects.js'}, function() {
          chrome.tabs.executeScript(tab.id, {file:'effects2.js'});
        });
      });
    });
  });
}

